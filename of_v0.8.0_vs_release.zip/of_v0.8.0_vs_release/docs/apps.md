[openFrameworks](http://openframeworks.cc/) | [Documentation table of contents](table_of_contents.md)

Apps and Examples
=================

Examples
--------
Examples are now located in the root of oF at `examples/`.  
This folder will remain as a place to work on your own apps.

Hierarchy
---------
Just remember projects in `apps/` still need to be two levels deep.  

	apps/
		mySoundApp/ 

will not work

	apps/  
		soundApps/  
			mySoundApp/  
		miscApps/  
			experiments/

will work 