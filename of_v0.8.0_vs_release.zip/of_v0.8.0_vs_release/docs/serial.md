[openFrameworks](http://openframeworks.cc/) | [Documentation table of contents](table_of_contents.md)

Serial
======

There is the arduino sketch used for the serial example.  
Find it in `other/` folder.

Get it to work
--------------

2. Setup the arduino with an LED on pin 13 and get the blinking LED example to work. 
2. Then upload this code. 
3. Open the serial monitor and type the letter a.  It something takes 5-15 seconds to for serial i/o to respond.  You should see an LED blink and the letters ABC in the console. 
4. Then, close the monitor, take note of the port number (ie, `COM7`) and then compile the serial example, changing the com port to the right value. 